<?php

class Update_model extends CI_Model{

	function personal($user) 
	{
		$pupdates = array(
							'companyname' => $this->input->post('companyname'),
							'regaddr' => $this->input->post('companyaddress'),
							'pincode' => $this->input->post('pin'),
							'city' => $this->input->post('city')
						);
		$this->db->where('username', $user);
		$this->db->update('merchantprofile', $pupdates);

			return;
		
	}

	function contact($user) 
	{
		$cupdates = array(
							'email' => $this->input->post('email'),
							'mobile' => $this->input->post('mobile')
						 );
							
		$this->db->where('username', $user);
		$this->db->update('merchantprofile', $cupdates);

		return;
		
	}
	
	function newreg()
	{
		$cnt = $this->db->count_all('merchantprofile');
		$cnt++;
		$brand = $this->input->post('brandname');
		$merchant = mb_substr($brand, 0, 3).$cnt;
		
		$new = array(	'companyname' => $this->input->post('parentcompany'),
						'brandname' => $brand, 
						'regaddr' => $this->input->post('address'),
						'mobile' => $this->input->post('mobile'),
						'email' => $this->input->post('email'),
						'city' => $this->input->post('city'),
						'password' => md5($this->input->post('password')), 
						'pan' => $this->input->post('pan'),
						'username' => $this->input->post('username'),
						'pincode' => $this->input->post('pin'),
						'bankaccname' => $this->input->post('bankholder'), 
						'bankaccno' => $this->input->post('bankaccount'),
						'vattin' => $this->input->post('vattin'),
						'csttin' => $this->input->post('csttin'),
						'merchantcode' => $merchant,
						'account_type' => 'Admin'

					);
		$this->db->insert('merchantprofile',$new);
		return;

	}

	function newoutlet()
	{
		$cntt = $this->db->count_all('outletlist');
		$cntt++;
		$pm = $this->input->post('parentmerchant');
		$unique = mb_substr($pm, 0, 3).$cntt;
		$outlet = array(
							'parentmerchant' => $this->input->post('parentmerchant'),
							'outletaddr' => $this->input->post('address'),
							'merchantcode' => $this->input->post('merchantcode'),
							'uniqueoutletcode' => $unique,
							'outpincode' => $this->input->post('pin'),
							'outlocation' => '-',
							'locality' => $this->input->post('locality'),
							'username' => $this->input->post('username'),
							'outletcity' => $this->input->post('city')
							);
		$this->db->insert('outletlist', $outlet);

		$profile = array(	'companyname' => $this->input->post('company'),
							'brandname' => $this->input->post('parentmerchant'),
							'regaddr' => $this->input->post('address'),
							'mobile' => '-',
							'email' => '-',
							'city' => $this->input->post('city'),
							'password' => md5($this->input->post('password')), 
							'pan' => '-',
							'username' => $this->input->post('username'),
							'pincode' => $this->input->post('pin'),
							'bankaccname' => '-', 
							'bankaccno' => '-',
							'vattin' => '-',
							'csttin' => '-',
							'merchantcode' => $this->input->post('merchantcode'),
							'isactive' => '1',
							'account_type' => 'Manager'

					);
		$this->db->insert('merchantprofile', $profile);
		return;
	}	


	function sproduct()
	{
		$user = $this->input->post('username');

		$image_path = realpath(APPPATH.'../images');
		
		$config = array(
							'allowed_types' => 'jpg|jpeg|png|gif|bmp',
							'upload_path' =>  $image_path,
							'encrypt_name' => TRUE
						);

		$this->load->library('upload',$config);
		$this->upload->do_upload();
		$image_data = $this->upload->data('file_name');
		$newimage = base_url("images/$image_data");
		$this->load->helper('date');
		$updateimg = array( 'image' => $newimage );
		$cc = $this->input->post('daterange');
		$cc_explode = explode(' - ', $cc);
		$start = $cc_explode[0];
		$enddate = $cc_explode[1];
		$nstart = nice_date($start, 'Y-m-d'); ;
		$nenddate = nice_date($enddate, 'Y-m-d'); ;
		$nnenddate = date_create($nenddate);
		$nnstart = date_create($nstart);
		$diff = date_diff($nnstart,$nnenddate);
		$runtime = $diff->format("%a");
		$duration = $runtime;

		$updates = array('merchantcode' => $this->input->post('merchantc'),
						 'adimage' => $newimage,
						 'pricingmarker' => 'T2',
						 'advertproductcode' => $this->input->post('barcode'),
						 'startdate' => $nstart,
						 'enddate' => $nenddate,
						 'isactive' => '5',
						 'adlifestyle' => $this->input->post('lifestyle'),
						 'adruntime' => $runtime,
						 'adruntimecount' => $runtime,
						 'addesc' => $this->input->post('cdescription'),
						 'adtype' => '1',
						 'advertprodname' => $this->input->post('pname'),
						 'interdate' => date("Y/m/d"),
						 'duration' => $duration
						  );
		$this->db->insert('advertlist',$updates);
		return;
	}

	function pproduct()
	{
		$user = $this->input->post('username');

		$image_path = realpath(APPPATH.'../images');
		
		$config = array(
							'allowed_types' => 'jpg|jpeg|png|gif|bmp',
							'upload_path' =>  $image_path,
							'encrypt_name' => TRUE
						);

		$this->load->library('upload',$config);
		$this->upload->do_upload();
		$image_data = $this->upload->data('file_name');
		$newimage = base_url("images/$image_data");
		$this->load->helper('date');
		$updateimg = array( 'image' => $newimage );
		$cc = $this->input->post('daterange');
		$cc_explode = explode(' - ', $cc);
		$start = $cc_explode[0];
		$enddate = $cc_explode[1];
		$nstart = nice_date($start, 'Y-m-d'); ;
		$nenddate = nice_date($enddate, 'Y-m-d'); ;
		$nnenddate = date_create($nenddate);
		$nnstart = date_create($nstart);
		$diff = date_diff($nnstart,$nnenddate);
		$runtime = $diff->format("%a");
		$duration = $runtime;

		$updates = array('merchantcode' => $this->input->post('merchantc'),
						 'adimage' => $newimage,
						 'pricingmarker' => 'T1',
						 'advertproductcode' => $this->input->post('barcode'),
						 'startdate' => $nstart,
						 'enddate' => $nenddate,
						 'isactive' => '5',
						 'adlifestyle' => $this->input->post('lifestyle'),
						 'adruntime' => $runtime,
						 'adruntimecount' => $runtime,
						 'addesc' => $this->input->post('cdescription'),
						 'adtype' => '1',
						 'advertprodname' => $this->input->post('pname'),
						 'interdate' => date("Y/m/d"),
						 'duration' => $duration,
						 'notiftext' => $this->input->post('anotification'),
						 'notiftextdisplay' => $this->input->post('dnotification')
						  );
		$this->db->insert('advertlist',$updates);
		return;
	}

	function sevent()
	{
		$user = $this->input->post('username');

		$image_path = realpath(APPPATH.'../images');
		
		$config = array(
							'allowed_types' => 'jpg|jpeg|png|gif|bmp',
							'upload_path' =>  $image_path,
							'encrypt_name' => TRUE
						);

		$this->load->library('upload',$config);
		$this->upload->do_upload();
		$image_data = $this->upload->data('file_name');
		$newimage = base_url("images/$image_data");
		$this->load->helper('date');
		$updateimg = array( 'image' => $newimage );
		$cc = $this->input->post('daterange');
		$cc_explode = explode(' - ', $cc);
		$start = $cc_explode[0];
		$enddate = $cc_explode[1];
		$nstart = nice_date($start, 'Y-m-d'); ;
		$nenddate = nice_date($enddate, 'Y-m-d'); ;
		$nnenddate = date_create($nenddate);
		$nnstart = date_create($nstart);
		$diff = date_diff($nnstart,$nnenddate);
		$runtime = $diff->format("%a");
		$duration = $runtime;

		$updates = array('merchantcode' => $this->input->post('merchantc'),
						 'adimage' => $newimage,
						 'pricingmarker' => 'T2',
						 
						 'startdate' => $nstart,
						 'enddate' => $nenddate,
						 'isactive' => '5',
						 'adlifestyle' => $this->input->post('lifestyle'),
						 'adruntime' => $runtime,
						 'adruntimecount' => $runtime,
						 'addesc' => $this->input->post('cdescription'),
						 'adtype' => '2',
						 'adverteventname' => $this->input->post('bname'),
						 'interdate' => date("Y/m/d"),
						 'duration' => $duration
						  );
		$this->db->insert('advertlist',$updates);
		return;
	}

	function pevent()
	{
		$user = $this->input->post('username');

		$image_path = realpath(APPPATH.'../images');
		
		$config = array(
							'allowed_types' => 'jpg|jpeg|png|gif|bmp',
							'upload_path' =>  $image_path,
							'encrypt_name' => TRUE
						);

		$this->load->library('upload',$config);
		$this->upload->do_upload();
		$image_data = $this->upload->data('file_name');
		$newimage = base_url("images/$image_data");
		$this->load->helper('date');
		$updateimg = array( 'image' => $newimage );
		$cc = $this->input->post('daterange');
		$cc_explode = explode(' - ', $cc);
		$start = $cc_explode[0];
		$enddate = $cc_explode[1];
		$nstart = nice_date($start, 'Y-m-d'); ;
		$nenddate = nice_date($enddate, 'Y-m-d'); ;
		$nnenddate = date_create($nenddate);
		$nnstart = date_create($nstart);
		$diff = date_diff($nnstart,$nnenddate);
		$runtime = $diff->format("%a");
		$duration = $runtime;

		$updates = array('merchantcode' => $this->input->post('merchantc'),
						 'adimage' => $newimage,
						 'pricingmarker' => 'T1',
						 
						 'startdate' => $nstart,
						 'enddate' => $nenddate,
						 'isactive' => '5',
						 'adlifestyle' => $this->input->post('lifestyle'),
						 'adruntime' => $runtime,
						 'adruntimecount' => $runtime,
						 'addesc' => $this->input->post('cdescription'),
						 'adtype' => '1',
						 'adverteventname' => $this->input->post('ename'),
						 'interdate' => date("Y/m/d"),
						 'duration' => $duration,
						 'notiftext' => $this->input->post('anotification'),
						 'notiftextdisplay' => $this->input->post('dnotification')
						  );
		$this->db->insert('advertlist',$updates);
		return;
	}
}