<?php

class Fetch extends CI_Model{

	function fetch_profile() 
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query = $this->db->get('merchantprofile');

			foreach ($query->result() as $row)
					{
						$data[] = $row;
					}

			return $data;
		
	}

	function fetch_outlet()
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query2 = $this->db->get('merchantprofile');
		if($query2->num_rows() > 0)
		{
		foreach ($query2->result() as $row)
				{
					$mcode = $row->merchantcode;
				}
		}


		$this->db->where('merchantcode' , $mcode);
		$outlet = $this->db->get('outletlist');
		if($outlet->num_rows() > 0)
		{
		foreach ($outlet->result() as $row)
					{
						$data2[] = $row;
					}

			return $data2;
		}
			
			
	}

	function fetch_transactions()
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query3 = $this->db->get('merchantprofile');
		if($query3->num_rows() > 0)
		{
		foreach ($query3->result() as $row)
				{
					$mercode = $row->merchantcode;
				}
		}
		$this->db->where('merchantcode' , $mercode);
		$this->db->order_by('transactiondate', 'DESC');
		$transactions = $this->db->get('transactionlist');
		if($transactions->num_rows() > 0)
		{
		foreach ($transactions->result() as $row)
					{
						$data3[] = $row;
					}

			return $data3;
		}
	}

	function fetch_adlist()
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query4 = $this->db->get('merchantprofile');
		if($query4->num_rows() > 0)
		{
		foreach ($query4->result() as $row)
				{
					$merccode = $row->merchantcode;
				}
		}
		$this->db->where('merchantcode' , $merccode);
		$ads = $this->db->get('advertlist');
		if($ads->num_rows() > 0)
		{
		foreach ($ads->result() as $row)
					{
						$data4[] = $row;
					}

			return $data4;
		}
	}

	function status()
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$stat = $this->db->get('merchantprofile');
		if($stat->num_rows() > 0)
		{
		foreach ($stat->result() as $row)
				{
					$stats = $row->isactive;
				}

			return $stats;
		}
	}

}