<?php
class Register extends CI_Controller {

	       

        function reg_admin()
        {
				$records = array('username' => $this->input->post('username'),
										'password' => $this->input->post('password'),
										'brandname' => $this->input->post('brandname'),
										'parentcompany' => $this->input->post('parentcompany')
									 );
				$this->load->view('register',$records);

		}

		function final_register()
		{
			$this->load->model('Update_model');
			$this->Update_model->newreg();
			$this->load->view('login');
		}

}