<?php
class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	}

	function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');

		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			echo 'You dont have permission to access this page. <a href="../login">Login</a> ';
			die();
		}
	}
        

        function merchant()
        {
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('home',$data);	

		}

		function admin()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$active = $this->Fetch->status();
			if ($active === '1') {
				$this->load->view('pmetrics',$data);
			}
			else {
				$this->load->view('inactive_profile',$data);
			}
			
		}

		function manager()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('manager_transactions',$data);
		}

		function logout()
		{
			$this->session->sess_destroy();
			$this->load->view('login');

		}

		function profile()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('profile',$data);	

		}

		function sproduct()
		{
			
				$this->load->model('Update_model');
				$img = $this->Update_model->sproduct();
				
			
			$this->admin();
		}

		function pproduct()
		{
			
				$this->load->model('Update_model');
				$img = $this->Update_model->pproduct();
				
			
			$this->admin();
		}

		function pevent()
		{
			
				$this->load->model('Update_model');
				$img = $this->Update_model->pevent();
				
			
			$this->admin();
		}

		function sevent()
		{
			
				$this->load->model('Update_model');
				$img = $this->Update_model->sevent();
				
			
			$this->admin();
		}

		function performance_metrics()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('pmetrics',$data);
		}

		function ad_metrics()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$data['records4'] = $this->Fetch->fetch_adlist();
			$this->load->view('ametrics',$data);
		}

		function transactions()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$data['records3'] = $this->Fetch->fetch_transactions();
			$this->load->view('transactions',$data);
		}

		function qrcode()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('qrcode',$data);
		}

		function manager_qrcode()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('manager_qrcode',$data);
		}

		function outlets()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('outlets',$data);
		}

		function standard_ads()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('standard_ads',$data);
		}

		function premium_ads()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('premium_ads',$data);
		}
}