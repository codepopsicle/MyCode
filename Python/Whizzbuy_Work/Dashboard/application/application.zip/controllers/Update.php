<?php
class Update extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	}

	function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');

		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			echo 'You dont have permission to access this page. <a href="../login">Login</a> ';
			die();
		}
	}
        
		function profile()
		{
			$this->load->model('Fetch');
			$data['records'] = $this->Fetch->fetch_profile();
			$data['records2'] = $this->Fetch->fetch_outlet();
			$this->load->view('profile',$data);	

		}
        
        function personal()
        {
			$this->load->model('Update_model');
			$this->Update_model->personal($this->session->userdata('username'));			
			$this->profile();	
		}

		function contact()
        {
			$this->load->model('Update_model');
			$this->Update_model->contact($this->session->userdata('username'));			
			$this->profile();
		}

		function outletadd()
		{
			$this->load->model('Update_model');
			$this->Update_model->newoutlet();			
			$this->profile();
		}
}