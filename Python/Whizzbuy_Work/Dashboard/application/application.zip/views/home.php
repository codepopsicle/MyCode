<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>WhizzBuy</title>
    <meta name="description" content="WhizzBuy"/>

    <meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">

    <!-- Loading Bootstrap -->
    <link href="<?php echo base_url('dist/css/vendor/bootstrap.min.css'); ?>" rel="stylesheet">
    <script src="<?php echo base_url('dist/js/vendor/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('dist/js/vendor/video.js'); ?>"></script>
    <script src="<?php echo base_url('dist/js/flat-ui.min.js'); ?>"></script>
    <script src="<?php echo base_url('docs/assets/js/application.js'); ?>"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">


    <!-- Loading Flat UI -->
    <link href="<?php echo base_url('dist/css/flat-ui.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('docs/assets/css/demo.css'); ?>" rel="stylesheet">
    <script src="<?php echo base_url('dist/js/qrcode.js'); ?>"></script>
    <script src="<?php echo base_url('dist/js/jquery.qrcode.js'); ?>"></script>

    <link rel="shortcut icon" href="<?php echo base_url('img/favicon.ico'); ?>">

<script type="text/javascript">
$(document).ready(function() {
if(location.hash) {
    $('a[href=' + location.hash + ']').tab('show');
}
  $(document.body).on("click", "a[data-toggle]", function(event) {
      location.hash = this.getAttribute("href");
  });
});
$(window).on('popstate', function() {
  var anchor = location.hash || $("a[data-toggle=tab]").first().attr("href");
  $('a[href=' + anchor + ']').tab('show'); });
</script>

    <style type="text/css">
      .nav1txt{
        font-size: 60%;
      }
      .list1txt{
        font-size: 80%
      }
      .nav1{padding-bottom: -5px;
        margin-bottom: -20px;}

      .shrink{
        margin-top: -25px;
        margin-right: -40px;
      }

      .nav2, .nav3{
        padding: 20px;
        padding-top: 0px;
        padding-bottom: 0px;
        
      }
      

      header{
        background-color: #99FFCC;
            width:100%;
            position:fixed;
            top:0px;
            z-index: 1;
      }

      .btn-transparent{
        background: transparent;

      }
      .btn-transparent:hover{
        background: #000000;
      }

      .main-content{
        padding-top: 140px;
        padding-left: 90px;
        padding-right: 90px;
      }

      .borderless tbody tr td, .borderless tbody tr th, .borderless thead tr th {
        border: none;
        }
      .datapoint{
        padding: 10px;
        background: #EAFFFF;
        -o-transition:.5s;
        -ms-transition:.5s;
        -moz-transition:.5s;
        -webkit-transition:.5s;
         transition:.5s;

      }

      .datapoint:hover{
        color:#ffffff;
        background: #000000;

      }
      .well{
        border-radius: 0px;
        box-shadow: 2px 2px 5px #888888;
      }

      p.smalls{
        line-height: 90%;

      }

      .disabled{
        color:#858585;
      }

      p.weights{
        font-weight: 900;
      }
    </style>

    
   

    <script type="text/javascript" src="https://www.google.com/jsapi"></script>

    <!--Total number of transactions at their stores via Whizzbuy-->
    <script type="text/javascript">
      google.load('visualization', '1', {packages: ['corechart', 'bar']});
      google.setOnLoadCallback(drawBasic);

      function drawBasic() {

            var data = google.visualization.arrayToDataTable([
               ['Month', 'Transactions', { role: 'style' }],
               ['Jan', 102, 'color: #e5e4e2'],            // RGB value
               ['Feb', 265, 'color: #959595'],   
               ['Mar', 412, 'color: #e5e4e2'],
               ['Apr', 010, 'color: #959595' ],
                ['May', 321, 'color: #e5e4e2' ],
                ['Jun', 055, 'color: #959595' ],
                ['Jul', 143, 'color: #e5e4e2' ],
                ['Aug', 125, 'color: #959595' ],
                ['Sep', 265, 'color: #e5e4e2' ],
                ['Oct', 235, 'color: #959595' ],
                ['Nov', 332, 'color: #e5e4e2' ],
                ['Dec', 411, 'color: #959595' ]
            ]);

            var options = {
              title: 'Total number of transactions at their stores via Whizzbuy',
              'height':300,
              legend: { position: "none" },
              chartArea: {width: '80%'},
              hAxis: {
                title: 'Total Number of Transactions',
                minValue: 0
              },
              vAxis: {
                title: 'Months'
              }
            };

            var chart = new google.visualization.BarChart(document.getElementById('numTransactions'));

            chart.draw(data, options);
          }
    </script>

    <!--Products with highest volume of sale-->
    <script type="text/javascript">
      google.load('visualization', '1', {packages: ['corechart', 'bar']});
      google.setOnLoadCallback(drawBasic);

      function drawBasic() {

            var data = google.visualization.arrayToDataTable([
               ['Month', 'Gross Transaction Value', { role: 'style' }],
               ['Jan', 25402, 'color: #0504f2'],            // RGB value
               ['Feb', 32565, 'color: #959595'],   
               ['Mar', 14212, 'color: #0504f2'],
               ['Apr', 21410, 'color: #959595' ],
                ['May', 36221, 'color: #0504f2' ],
                ['Jun', 14505, 'color: #959595' ],
                ['Jul', 25743, 'color: #0504f2' ],
                ['Aug', 26425, 'color: #959595' ],
                ['Sep', 14265, 'color: #0504f2' ],
                ['Oct', 21435, 'color: #959595' ],
                ['Nov', 21532, 'color: #0504f2' ],
                ['Dec', 26411, 'color: #959595' ]
            ]);

            var options = {
              title: 'Products with highest volume of sale',
              

              'height':300,
              legend: { position: "none" },
              chartArea: {width: '80%'},
              hAxis: {
                title: 'Gross Transaction Value',
                minValue: 10000,
              },
              vAxis: {
                title: 'Months'
              }
            };

            var chart = new google.visualization.BarChart(document.getElementById('productSale'));

            chart.draw(data, options);
          }
    </script>

    <!--Gross sales across Whizzbuy outlets-->
    <script type="text/javascript">
      google.load('visualization', '1', {packages: ['corechart', 'bar']});
      google.setOnLoadCallback(drawBasic);

      function drawBasic() {

            var data = google.visualization.arrayToDataTable([
               ['Month', 'Gross Transaction Value', { role: 'style' }],
               ['Jan', 25402, 'color: #f504f2'],            // RGB value
               ['Feb', 32565, 'color: #959595'],   
               ['Mar', 14212, 'color: #f504f2'],
               ['Apr', 21410, 'color: #959595' ],
                ['May', 36221, 'color: #f504f2' ],
                ['Jun', 14505, 'color: #959595' ],
                ['Jul', 25743, 'color: #f504f2' ],
                ['Aug', 26425, 'color: #959595' ],
                ['Sep', 14265, 'color: #f504f2' ],
                ['Oct', 21435, 'color: #959595' ],
                ['Nov', 21532, 'color: #f504f2' ],
                ['Dec', 26411, 'color: #959595' ]
            ]);

            var options = {
              title: 'Gross sales across WhizzBuy outlets',
              'height':300,
              chartArea: {width: '80%'},
              legend: { position: "none" },
              hAxis: {
                title: 'Gross Transaction Value',
                minValue: 10000
              },
              vAxis: {
                title: 'Months'
              }
            };

            var chart = new google.visualization.BarChart(document.getElementById('grossSales'));

            chart.draw(data, options);
          }
    </script>

    <!--Top Selling Products-->
    <script type="text/javascript">
    
      // Load the Visualization API and the piechart package.
      google.load('visualization', '1.0', {'packages':['corechart']});
      
      // Set a callback to run when the Google Visualization API is loaded.
      google.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table, 
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

      // Create the data table.
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Products');
      data.addColumn('number', 'Sales');
      data.addRows([
        ['Patanjali Dant Kanti', 102],
        ['Smartfish', 43],
        ['Lays Classic Salt', 55], 
        ['Oleev Active', 66],
        ['Surf Excel 400g', 38]
      ]);

      // Set chart options
      var options = {'title':'Top Selling Products',
                     chartArea: {width: '80%'},
                     'height':300};

      // Instantiate and draw our chart, passing in some options.
      var chart = new google.visualization.PieChart(document.getElementById('topProducts'));
      chart.draw(data, options);
    }
    </script>
    <script type="text/javascript">
      function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
    }
    </script>

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="dist/js/vendor/html5shiv.js"></script>
      <script src="dist/js/vendor/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <?php
      if(isset($records))
        foreach ($records as $row) 
        {
          $merchantid  = $row->merchantid;
          $companyname = $row->companyname;
          $brandname = $row->brandname;
          $regaddr = $row->regaddr;
          $mobile = $row->mobile;
          $email = $row->email;
          $pan = $row->pan;
          $username = $row->username;
          $merchantcode = $row->merchantcode;
          $isapproved = $row->isapproved;
          $isloggedin = $row->isloggedin;
          $isactive = $row->isactive;
          $pincode = $row->pincode;
          $city = $row->city;
          $bankaccname = $row->bankaccname;
          $bankaccno = $row->bankaccno;
          $vattin = $row->vattin;
          $csttin = $row->csttin;
          $kycpending = $row->kycpending;
          $account_type = $row->account_type;
        }

    ?>
    
    <header>
      <div class="nav2">
        <div class="row">
        <div class="col-md-7">
        <img src="<?php echo base_url('img/logo.png'); ?>" width="60">
        </div>
        <div class="col-md-2 shrink">
          <br><p><small>Account Status: <strong><?php if($isactive == 1) echo '&nbsp;&nbsp;ACTIVE'; else echo '&nbsp;&nbsp;INACTIVE'; ?></strong></small></p>
        </div>
        <div class="col-md-2 shrink"><br>
        <div class="dropdown">
          <button class="btn btn-xs btn-primary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            <?php echo $brandname; ?>
            <span class="caret"></span>
          </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
            <li><a href="<?php echo base_url('index.php/home/profile'); ?>">Manage Profile</a></li>
            <li><a href="<?php echo base_url('index.php/home/logout'); ?>">Logout</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-2 shrink">
          <br><button class="btn btn-xs btn-primary" >Contact</button>
        </div>
    </div>

      </div>

<!--       <div class="nav3">
        <div class="row">
          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Listings
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Add Listings in Bulk</a></li>
                <li><a href="#">Add a Listing</a></li>
                <li><a href="#">My Listings</a></li>
                <li><a href="#">Track Approval Requests</a></li>
              </ul>
            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Orders
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Active Orders</a></li>
                <li><a href="#">Cancelled Orders</a></li>
                
              </ul>
            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Returns
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Returns</a></li>
                <li><a href="#">Disputes</a></li>
               
              </ul>
            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Payments
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Settlements</a></li>
                <li><a href="#">Statements</a></li>
                <li><a href="#">Transactions</a></li>
                <li><a href="#">Invoices</a></li>
              </ul>
            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <a href="metrics.html"><button class="btn btn-transparent btn-block  btn-sm" type="button" aria-haspopup="true" aria-expanded="true">
                Metrics

              </button></a>

            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Promotions
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">My Promotions</a></li>
                <li><a href="#">WhizzBuy Promotions</a></li>

              </ul>
            </div>
          </div>

          <div class="col-md-1">
            <div class="dropdown">
              <button class="btn btn-transparent  btn-sm" type="button" aria-haspopup="true" aria-expanded="true">
                Advertising

              </button>

            </div>
          </div>

        </div>

      </div> -->
    <div class="nav3">
      <br>
      <div>

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#metrics" aria-controls="metrics" role="tab" data-toggle="tab">Metrics</a></li>
          <li role="presentation"><a href="#transactions" aria-controls="transactions" role="tab" data-toggle="tab">Transactions</a></li>
          <li role="presentation"><a href="#wbads" aria-controls="wbads" role="tab" data-toggle="tab">WB Ads</a></li>
          <li role="presentation"><a href="#qrcode" aria-controls="qrcode" role="tab" data-toggle="tab">QR Code</a></li>
          <li role="presentation"><a href="#myoutlets" aria-controls="myoutlets" role="tab" data-toggle="tab">My Outlets</a></li>
          <li role="presentation"><a href="#admetrics" aria-controls="admetrics" role="tab" data-toggle="tab">Ad Metrics</a></li>
        </ul>

        <!-- Tab panes -->
        

      </div>
    </div>

    </header>
    





<div class="main-content">
<div class="row">
<div class="col-md-12">
  <div class="tab-content">
          <div role="tabpanel" class="tab-pane active" id="metrics">

            <div class="row">
             <h4>Summary</h4>
             <div class="col-md-3">
              <div class="well datapoint">
                <p class="smalls text-center weights">184</p>
                <p class="list1txt text-center smalls disabled">Total WhizzBuy Users</p>
              </div>
             </div>
              <div class="col-md-3">
              <div class="well datapoint">
                <p class="smalls text-center weights">114</p>
                <p class="list1txt text-center smalls disabled">Returning Customers at your Store</p>
              </div>
             </div>
              <div class="col-md-3">
              <div class="well datapoint">
                <p class="smalls text-center weights">542</p>
                <p class="list1txt text-center smalls disabled">Total Transactions</p>
              </div>
             </div>
              <div class="col-md-3">
              <div class="well datapoint">
                <p class="smalls text-center weights">₹ 84214</p>
                <p class="list1txt text-center smalls disabled">Gross sales value via Whizzbuy</p>
              </div>
             </div>
            </div>
            <div class="row">
               <div class="col-md-6">
              <div class="well datapoint">
                <p class="smalls text-center weights">₹ 441125</p>
                <p class="list1txt text-center smalls disabled">Total transactions on WhizzBuy</p>
              </div>
             </div>
              <div class="col-md-6">
              <div class="well datapoint">
                <p class="smalls text-center weights">14</p>
                <p class="list1txt text-center smalls disabled">Registered Outlets</p>
              </div>
             </div>
            </div>
            <div class ="row">
              <h4>Trends</h4>
                 <div class="col-md-6">
              <div class="well datapoint">
                <p class="list1txt text-center smalls disabled">Total number of transactions at your stores via Whizzbuy</p>
                <!-- <div>
                  <select>
                    <option>1</option>
                    <option>2</option>
                  </select>
                </div> -->
                <div id="numTransactions"></div>
              </div>
             </div>
              <div class="col-md-6">
              <div class="well datapoint">
                <p class="list1txt text-center smalls disabled">Products with highest volume of sale</p>
                <div id="productSale"></div>
              </div>
             </div>
            </div>

            <div class ="row">
              
                 <div class="col-md-6">
              <div class="well datapoint">
                <p class="list1txt text-center smalls disabled">Gross sales across Whizzbuy outlets</p>
                <div id="grossSales"></div>
              </div>
             </div>
              <div class="col-md-6">
              <div class="well datapoint">
                <p class="list1txt text-center smalls disabled">Top Selling Products</p>
                <div id="topProducts"></div>
              </div>
             </div>
            </div>
            <div class ="row">
              <div class="col-md-3"></div>
                 <div class="col-md-6">
              <div class="well datapoint">


                <p class="list1txt text-center smalls disabled">Top 10 Spenders</p>
                <table class="table table-condensed list1txt smalls">
                  <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Amount Spent</th>
                  </tr>
                  <tr>
                    <td>1.</td>
                    <td>Abhinav Pandey</td>
                    <td>₹ 25146</td>
                  </tr>
                  <tr>
                    <td>2.</td>
                    <td>Harshit Mishra</td>
                    <td>₹ 21146</td>
                  </tr>
                  <tr>
                    <td>3.</td>
                    <td>Ashish Verma</td>
                    <td>₹ 20046</td>
                  </tr>
                  <tr>
                    <td>4.</td>
                    <td>Yogesh</td>
                    <td>₹ 19996</td>
                  </tr>
                  <tr>
                    <td>5.</td>
                    <td>Disha Pal</td>
                    <td>₹ 19625</td>
                  </tr>
                  <tr>
                    <td>6.</td>
                    <td>Amitabh</td>
                    <td>₹ 15423</td>
                  </tr>
                  <tr>
                    <td>7.</td>
                    <td>Salman Khan</td>
                    <td>₹ 14253</td>
                  </tr>
                  <tr>
                    <td>8.</td>
                    <td>Irrfan Khan</td>
                    <td>₹ 13254</td>
                  </tr>
                  <tr>
                    <td>9.</td>
                    <td>Rahul Dubey</td>
                    <td>₹ 11024</td>
                  </tr>
                  <tr>
                    <td>10.</td>
                    <td>Bejan</td>
                    <td>₹ 101</td>
                  </tr>
                </table>
              </div>

             </div>
            <div class="col-md-3"></div>
            </div>

          </div>
          <div role="tabpanel" class="tab-pane" id="transactions"><h1>Tab Transactions</h1></div>
          <div role="tabpanel" class="tab-pane" id="wbads">3</div>
          
          <div role="tabpanel" class="tab-pane" id="qrcode">
            <br>
            <div class="row">
              <div class="col-md-6">
                <div class="well ">
                  <h4>Merchant ID: <span id="data1">NATU000001</span></h4>
                  <div class="form-horizontal">
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Outlet ID: </label>
                        <div class="col-sm-8">
                          <select id="data2">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                        </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">WiFi Ap Name: </label>
                        <div class="col-sm-8">
                          <input type="text" placeholder="WiFi Ap Name" id="data3">
                        </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">WiFi Ap Password: </label>
                        <div class="col-sm-8">
                          <input type="text" placeholder="WiFi Ap Password" id="data4">
                        </div>
                    </div>
                    <script type="text/javascript">
                    function getdata(){
                      var d1 = document.getElementById("data1").innerHTML;
                      var d2 = document.getElementById("data2").value;
                      var d3 = document.getElementById("data3").value;
                      var d4 = document.getElementById("data4").value;
                      var fin = d1+';'+d2+';'+d3+';'+d4+';';
                      // qrcode.clear();
                      $(document).ready(function() {
                          $('#qrcode11').qrcode({width: 300,height: 300, text: ""});
                          $('#qrcode11').qrcode.text=fin;

                      });
                    }
                  </script>
                    <div class="form-group">
                      <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-4 col-sm-offset-2">
                          <button class="btn btn-danger btn-sm btn-block" onclick="getdata()" >Generate</button>
                        </div>
                    </div>
                  </div>
                  
                </div>
              </div>
              <div class="col-md-6">
                <div class="well">
                  <div class="row">
                    <div class="col-md-6 pull-left">
                      <button class="btn btn-primary"><i class="fa fa-floppy-o"></i> Save</button>
                    </div>
                    <div class="col-md-6 pull-right">
                      <button class="btn btn-primary" onclick="printDiv('qrcode11')"><i class="fa fa-print"></i> Print</button>
                    </div>
                  </div>
                  <hr>
                  <div id="qrcode11" style="width=250px;" class="center-class"></div>
                  <script type="text/javascript">

                   </script>
                </div>
                
              </div>
            </div>
          </div>
          
          <div role="tabpanel" class="tab-pane" id="myoutlets">
          <div class="row"><h2>My Outlets</h2><br><hr>

            <div class="col-md-8">
             
              <?php if(isset($records2)): ?>
              <?php foreach ($records2 as $row): ?>
              <div class="well">
                  <table class="table borderless">
                    <tr>
                      <td class="list1txt" width="30%">Outlet Code<br></td>
                      <td class="list1txt" width="70%"><?php echo $row->uniqueoutletcode; ?></td>
                    </tr>
                    <tr>
                      <td class="list1txt">Outlet Name</td>
                      <td class="list1txt"><?php echo $row->locality; ?></td>
                    </tr>
                    <tr>
                      <td class="list1txt">Outlet Address</td>
                      <td class="list1txt"><?php echo $row->outletaddr; ?></td>
                    </tr>
                    <tr>
                      <td class="list1txt"></td>
                      <td class="list1txt"><button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#my<?php echo $row->outletid; ?>">Edit</button></td>
                    </tr>
                  </table>
                  <!-- Modal -->
                  <div class="modal fade" id="my<?php echo $row->outletid; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel">Edit Outlet: <?php echo $row->outletaddr; ?></h4>
                        </div>
                      <div class="modal-body">
                        
                          <form class="form-horizontal" action="<?php echo base_url('index.php/update/personal'); ?>" method="post">
                            <div class="form-group">
                            <input type="hidden"  class="form-control" name="outletid" value="<?php echo $row->outletid; ?>" >
                            </div>
                            <div class="form-group">
                              <label class="col-sm-2 control-label">Outlet Address</label>
                                <div class="col-sm-10">
                                  <textarea class="form-control" rows="3" name="address" value="<?php echo $row->outletaddr; ?>"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet PIN Code</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="pin" value="<?php echo $row->outpincode; ?>">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet Location</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="location" value="<?php echo $row->outlocation; ?>">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet Locality</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="locality" value="<?php echo $row->locality; ?>">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet City</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="city" value="<?php echo $row->outletcity; ?>">
                                  </div>
                            </div>
                      </div>

                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save changes</button>
                          </form>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>

                      </div>
                    </div>
                  </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
          <?php echo '<h3>No Outlets Registered<br>Register New Outlets</h3>'; ?>
        <?php endif; ?>



            </div>

            <div class="col-md-4">
                <button class="btn btn-block btn-success btn-lg" data-toggle="modal" data-target="#addOutlet">Add New Outlet</button>
              </div>

              <!-- Modal -->
              <div class="modal fade" id="addOutlet" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title" id="myModalLabel">Add New Outlet</h4>
                    </div>
                    <div class="modal-body">
                      <form class="form-horizontal" action="<?php echo base_url('index.php/update/outletadd'); ?>" method="post">
                            <div class="form-group">
                              <input type="hidden"  class="form-control" name="company" value="<?php echo $companyname; ?>">
                            <input type="hidden"  class="form-control" name="parentmerchant" value="<?php echo $brandname; ?>">
                            <input type="hidden"  class="form-control" name="merchantcode" value="<?php echo $merchantcode; ?>">
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Username</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="username" placeholder="Username for login">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Password</label>
                                  <div class="col-sm-10">
                                    <input type="password"  class="form-control" name="password" placeholder="Password">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Email ID</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="email" placeholder="Email ID">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Mobile</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="mobile" placeholder="Mobile Number">
                                  </div>
                            </div>
                            <div class="form-group">
                              <label class="col-sm-2 control-label">Outlet Address</label>
                                <div class="col-sm-10">
                                  <textarea class="form-control" rows="3" name="address" ></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet PIN Code</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="pin" placeholder="PIN Code of the Outlet">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet Location</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="location" placeholder="Location of the Outlet">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet Locality</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="locality" placeholder="Locality of the Outlet">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Outlet City</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" name="city" placeholder="City of the Outlet">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">PAN Card</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="pan" placeholder="PAN Card Number">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Bank Account Holder Name</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="bankholder" placeholder="Bank Account Holder\'s Name">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Bank Account Number</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="bankaccount" placeholder="Bank Account Number">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">VAT TIN Number</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="vat" placeholder="VAT TIN Number">
                                  </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">CST TIN Number</label>
                                  <div class="col-sm-10">
                                    <input type="text"  class="form-control" name="cst" placeholder="CST TIN Number">
                                  </div>
                            </div>
                      </div>

                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                          </form>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      
                    </div>
                  </div>
                </div>
              </div>



          </div>
          </div>
          <div role="tabpanel" class="tab-pane" id="admetrics">6</div>
    </div>
  
</div>
</div>
</div> 


    <footer>

    </footer>
    

    <script>
      videojs.options.flash.swf = "<?php echo base_url('dist/js/vendors/video-js.swf'); ?>"
    </script>
  </body>
</html>
