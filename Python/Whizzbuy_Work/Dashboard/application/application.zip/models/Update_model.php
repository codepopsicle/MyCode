<?php

class Update_model extends CI_Model{

	function personal($user) 
	{
		$pupdates = array(
							'companyname' => $this->input->post('companyname'),
							'regaddr' => $this->input->post('companyaddress'),
							'pincode' => $this->input->post('pin'),
							'city' => $this->input->post('city')
						);
		$this->db->where('username', $user);
		$this->db->update('merchantprofile', $pupdates);

			return;
		
	}

	function contact($user) 
	{
		$cupdates = array(
							'email' => $this->input->post('email'),
							'mobile' => $this->input->post('mobile')
						 );
							
		$this->db->where('username', $user);
		$this->db->update('merchantprofile', $cupdates);

		return;
		
	}
	
	function newreg()
	{
		$cnt = $this->db->count_all('merchantprofile');
		$cnt++;
		$brand = $this->input->post('brandname');
		$merchant = mb_substr($brand, 0, 3).$cnt;
		
		$new = array(	'companyname' => $this->input->post('parentcompany'),
						'brandname' => $brand, 
						'regaddr' => $this->input->post('address'),
						'mobile' => $this->input->post('mobile'),
						'email' => $this->input->post('email'),
						'city' => $this->input->post('city'),
						'password' => md5($this->input->post('password')), 
						'pan' => $this->input->post('pan'),
						'username' => $this->input->post('username'),
						'pincode' => $this->input->post('pin'),
						'bankaccname' => $this->input->post('bankholder'), 
						'bankaccno' => $this->input->post('bankaccount'),
						'vattin' => $this->input->post('vattin'),
						'csttin' => $this->input->post('csttin'),
						'merchantcode' => $merchant,
						'account_type' => 'Admin'

					);
		$this->db->insert('merchantprofile',$new);
		return;

	}

	function newoutlet()
	{
		$cntt = $this->db->count_all('outletlist');
		$cntt++;
		$pm = $this->input->post('parentmerchant');
		$unique = mb_substr($pm, 0, 3).$cntt;
		$outlet = array(
							'parentmerchant' => $this->input->post('parentmerchant'),
							'outletaddr' => $this->input->post('address'),
							'merchantcode' => $this->input->post('merchantcode'),
							'uniqueoutletcode' => $unique,
							'outpincode' => $this->input->post('pin'),
							'outlocation' => $this->input->post('location'),
							'locality' => $this->input->post('locality'),
							'outletcity' => $this->input->post('city')
							);
		$this->db->insert('outletlist', $outlet);

		$profile = array(	'companyname' => $this->input->post('company'),
							'brandname' => $this->input->post('parentmerchant'),
							'regaddr' => $this->input->post('address'),
							'mobile' => $this->input->post('mobile'),
							'email' => $this->input->post('email'),
							'city' => $this->input->post('city'),
							'password' => md5($this->input->post('password')), 
							'pan' => $this->input->post('pan'),
							'username' => $this->input->post('username'),
							'pincode' => $this->input->post('pin'),
							'bankaccname' => $this->input->post('bankholder'), 
							'bankaccno' => $this->input->post('bankaccount'),
							'vattin' => $this->input->post('vat'),
							'csttin' => $this->input->post('cst'),
							'merchantcode' => $this->input->post('merchantcode'),
							'account_type' => 'Manager'

					);
		$this->db->insert('merchantprofile', $profile);
		return;
	}	


}