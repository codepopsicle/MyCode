<?php

class Fetch extends CI_Model{

	function fetch_profile() 
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query = $this->db->get('merchantprofile');

			foreach ($query->result() as $row)
					{
						$data[] = $row;
					}

			return $data;
		
	}

	function fetch_outlet()
	{
		$this->db->where('username' , $this->session->userdata('username'));
		$query2 = $this->db->get('merchantprofile');
		if($query2->num_rows() > 0)
		{
		foreach ($query2->result() as $row)
				{
					$mcode = $row->merchantcode;
				}
		}


		$this->db->where('merchantcode' , $mcode);
		$outlet = $this->db->get('outletlist');
		if($outlet->num_rows() > 0)
		{
		foreach ($outlet->result() as $row)
					{
						$data2[] = $row;
					}

			return $data2;
		}
			
			
	}



}